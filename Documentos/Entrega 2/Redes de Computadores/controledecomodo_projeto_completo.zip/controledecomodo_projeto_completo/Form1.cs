using System;
using System.Windows.Forms;

namespace ControleDeComodo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string comodoSelecionado = comboBox1.SelectedItem.ToString();

            if (comodoSelecionado == "Sala")
            {
                labelStatus.Text = "Luz e umidificador ligados na Sala.";
            }
            else if (comodoSelecionado == "Quarto")
            {
                labelStatus.Text = "Luz ligada e umidificador desligado no Quarto.";
            }
            else if (comodoSelecionado == "Cozinha")
            {
                labelStatus.Text = "Somente luz ligada na Cozinha.";
            }
        }
    }
}